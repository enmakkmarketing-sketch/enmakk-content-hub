# ENMAKK Content Hub

This repository stores ENMAKK articles related to uPVC, Aluminium, Hardware, and Fabrication.

## Folder Structure
- articles/
  - upvc/
  - aluminium/
  - hardware/
  - fabrication/
  - drafts/
- assets/
  - images/
  - diagrams/

## How to Use
1. Go to the folder matching your article category.
2. Add a new `.md` file using GitHub's *Create new file*.
3. Use the provided article template.
4. Commit changes.
5. Upload images inside `assets/images/`.

